const records = `{
    "movie" :[
      {
        "title": "이터널 선샤인",
        "star": "3"
      },
      {
        "title": "센과 치히로의 행방불명",
        "star": "4"
      }
    ]
  }`;
const recordsObj = JSON.parse(records);

// 센과 치히로의 행방불명 출력
console.log();