const login = '{"id":"aaa", "pw":"111"}';
const loginObj = {id:"aaa", pw:"111"};

console.log(login)
console.log(loginObj)

//문자열을 객체로 파싱
let json1 = JSON.parse(login);
console.log("\njson1 = " + json1);
console.log("json1.id = " + json1.id);

//객체를 문자열로 변경
let json2 = JSON.stringify(loginObj);
console.log("\njson2 = " + json2);
console.log("json2.id = " + json2.id);