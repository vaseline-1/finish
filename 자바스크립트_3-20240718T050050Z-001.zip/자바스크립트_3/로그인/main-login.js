
//submit 이벤트의 addEventListener 리스너 작성

//1. 폼전송 이벤트 취소


//username 요소를 가져옴

//username 요소의 값을 가져옴

//password 요소를 가져옴

//password 요소의 값을 가져옴


// 2 아이디 미입력시 경고창 표시


// 3 이메일 형식이 맞지 않을 경우


// 4 비밀번호가 입력되지 않은 경우


// 5 비밀번호 문자개수 확인


 // 6 전송


