
/////////// 0~ 1미만 난수
const rd = Math.random();
console.log(rd);

/////////// 0~4 난수
// for(let i=0; i<=20; i++)
//  console.log(Math.floor(Math.random() * 5)); 

