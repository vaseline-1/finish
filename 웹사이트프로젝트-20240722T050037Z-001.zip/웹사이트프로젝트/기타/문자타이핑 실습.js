//// 문자타이핑 준비 실습

///1. 문자열 분리 후 제일 앞의 문자열 추출하는 과정 실습
let spanEl = ""; 
const txtArr = ['Web Publisher', 'Front-End Developer', 'Web UI Designer', 'UX Designer', 'Back-End Developer'];
let index = 0;
let currentTxt = txtArr[index].split("");
//0번째 요소 Web Publisher 를 하나씩 분리해서 currentTxt에 저장
console.log("currentTxt : "+ currentTxt);

// currentTxt 값에서 제일 앞의 문자 하나를 추출해서 spanEl의 값에 더함

// spanEl += currentTxt.shift();
// console.log(">> spanEl : " + spanEl);
// console.log(">> shift()후 currentTxt =" + currentTxt);

// console.log("----------------------------------");

//// 2. currentTxt 배열의 맨 뒤의 값 하나를 삭제하는 과정 실습
//실습을 위해 다시 'Web Publisher' 를 하나씩 분리해서 할당함
// 아래 주석풀때 블록 선택 -> shift + alt + a 

/* currentTxt = txtArr[index].split("");
spanEl="";
currentTxt.pop();
console.log(">> pop()후 currentTxt =" + currentTxt);
//currentTxt 배열의 , 를 모두 없앤 후 spanEl 요소에 전달
spanEl += currentTxt.join("");
console.log(">> pop 후 spanEl에 전달된 값  => " + spanEl); */

