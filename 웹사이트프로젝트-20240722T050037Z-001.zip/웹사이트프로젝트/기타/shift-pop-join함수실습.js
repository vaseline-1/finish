// Array 객체 shift(), pop(), join() 함수 실습(p.435 참조)

/// 1. Array 객체 shift(), pop() 실습 

const arr = [10, 20, 30, 40];
for(let i in arr){
  console.log(arr[i]);
}
console.log("-----------------------------")
console.log(arr.shift())
console.log("----shift() 추출 후 배열-------")
for(let i in arr){
  console.log(arr[i]);
}
// pop도 해서 결과 볼 것



 //// 2. join() 함수 실습
// let strArr=['L','o','v','e'];
// console.log(strArr.join());
// console.log(strArr.join(""));
// console.log(strArr.join("*")); 


