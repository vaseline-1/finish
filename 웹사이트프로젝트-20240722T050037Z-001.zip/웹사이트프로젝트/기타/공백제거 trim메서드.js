
let str = " korea ";
console.log(str);
console.log(str.length); 
//문자열 앞뒤 공백제거
console.log(str.trim());
console.log(str.trim().length);

